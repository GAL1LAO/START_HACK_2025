# Instructions

1. Build the container image docker or podman
2. Run the container and map the "work" directory to "/home/jovyan/work" using a volume mount.
3. Make sure to get the "config.share" file to authorize access to the data, and include it in the volume mount.
